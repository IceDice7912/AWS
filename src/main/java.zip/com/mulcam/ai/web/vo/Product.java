package com.mulcam.ai.web.vo;

public interface Product {

}
