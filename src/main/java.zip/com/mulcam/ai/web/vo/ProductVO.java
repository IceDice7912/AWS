package com.mulcam.ai.web.vo;

public class ProductVO implements Product {
    private String product_name;
    private int price;

    public void setProduct_name(String product_name){
    }

    public String getProduct_name(){
        return null;
    }

}
