package com.mulcam.ai.web.dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.mulcam.ai.web.vo.OrderVO;

//@Mapper
//@Repository
public interface OrderDAO {
	
	/* public void insert(ArrayList<OrderVO> list); */

}
