package com.mulcam.ai.util;

public class CafeException extends Exception {

	public CafeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
